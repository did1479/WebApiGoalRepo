﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebApiGoalProject.Models;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;

namespace WebApiGoalProject.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            var locations = IndexAsync();

            return View(locations);
        }

        public List<LocationModel> IndexAsync()
        {
            var locations = GetLocationsAsync();

            return locations.Result;
        }

        private async Task<List<LocationModel>> GetLocationsAsync()
        {
            var locations = new List<LocationModel>();
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost/WebApi/");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                try
                {
                    HttpResponseMessage response = await client.GetAsync("locationapi/GetLocations");
                    if (response.IsSuccessStatusCode)
                    {
                        var loc = await response.Content.ReadAsAsync<List<LocationModel>>();
                        locations.AddRange(loc);
                    }
                    else
                    {
                        Console.WriteLine("Internal server Error");
                    }
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                }
            }

            return locations;
        }
    }
}
