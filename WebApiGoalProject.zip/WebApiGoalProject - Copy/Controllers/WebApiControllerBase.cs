﻿namespace WebApiGoalProject.Controllers
{
    using System.Web.Mvc;
    using WebApiGoalProject.DataService;
    using WebApiGoalProject.Location.interfaces;
    using System.Web.Http;

    public class WebApiControllerBase : ApiController
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="WebApiControllerBase" /> class.
        /// </summary>
        protected WebApiControllerBase()
        {
            this.LocationProvider = new LocationDataService();
        }

        /// <summary>
        ///     Gets the Location Provider.
        /// </summary>
        protected ILocationDataService LocationProvider { get; }
    }
}