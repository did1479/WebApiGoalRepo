﻿namespace WebApiGoalProject.Controllers
{
    using System.Threading.Tasks;
    using System.Web.Http;
    using System.Web.Mvc;
    using WebApiGoalProject.Helpers;
    using WebApiGoalProject.Models;
    using RouteAttribute = System.Web.Http.RouteAttribute;

    /// <summary>
    ///     The Test Api Controller.
    /// </summary>
    [Route("/locationapi")]
    public class TestApiController : WebApiControllerBase
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="TestApiController" /> class.
        /// </summary>
        public TestApiController()
            : base()
        {
        }

        /// <summary>
        ///     Simple "Hello World" method to ensure service is up.
        /// </summary>
        /// <returns>The literal "Hello World".</returns>
        [System.Web.Http.HttpGet]
        [Route("locationapi/HelloWorld")]
        public string GetHelloWorld() => $"{"HelloWorld"}{"  -  "}{this.Request.RequestUri.AbsoluteUri}";

        /// <summary>
        ///     Get all the Locations
        /// </summary>
        /// <returns>All Locations.</returns>
        [System.Web.Http.HttpGet]
        [Route("locationapi/GetLocations")]
        public async Task<JsonResult> GetLocations()
        {
            return await this.LocationProvider.GetLocations();
        }

        /// <summary>
        ///     Get Location Details.
        /// </summary>
        /// <param name="locationId">Location Id.</param>
        /// <returns>Location Details of given location id.</returns>
        [System.Web.Http.HttpGet]
        [Route("locationapi/GetLocationDetails/{locationId}")]
        public async Task<JsonResult> GetLocationDetail(int locationId)
        {
            if (locationId < 0)
            {
                return new JsonResult { Data = "Loation Id is not valid" };
            }

            return await this.LocationProvider.GetLocationDetail(locationId);
        }

        /// <summary>
        ///    Add a new Location.
        /// </summary>
        /// <param name="request">Request Object.</param>
        /// <returns>Location name and result.</returns>
        [System.Web.Http.HttpPost]
        [Route("locationapi/AddLocation")]
        public async Task<JsonResult> AddLocation([FromBody] [ModelBinder(typeof(LocationModelBinder))] LocationModel model)
        {
            if (ModelState.IsValid == false)
            {
                return new JsonResult { Data = "Model is not valid." };
            }

            var result = await this.LocationProvider.AddLocation(model);
            return new JsonResult { Data = result };
        }

        /// <summary>
        ///    Update a Location.
        /// </summary>
        /// <param name="request">Request Object.</param>
        /// <returns>Updated location name and result.</returns>
        [System.Web.Http.HttpPost]
        [Route("locationapi/UpdateLocation")]
        public async Task<JsonResult> Put([FromBody][ModelBinder(typeof(LocationModelBinder))] LocationModel model)
        {
            if (ModelState.IsValid == false)
            {
                return new JsonResult { Data = "Model is not valid." };
            }

            var result = await this.LocationProvider.UpdateLocation(model);
            return new JsonResult { Data = result };
        }

        /// <summary>
        ///    Delete a Location.
        /// </summary>
        /// <param name="locationId">Location Id to Delete.</param>
        /// <returns>Deleted location name and result.</returns>
        [System.Web.Http.HttpPost]
        [Route("locationapi/DeleteLocation")]
        public async Task<JsonResult> Delete(int locationId)
        {
            if (locationId > 0)
            {
                return new JsonResult { Data = "Location id is not valid." };
            }

            var result = await this.LocationProvider.DeletedLocation(locationId);
            return new JsonResult { Data = result };
        }
    }
}
