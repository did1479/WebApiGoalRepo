﻿namespace WebApiGoalProject.Helpers
{
    using System;
    using System.Web.Http.Controllers;
    using System.Web.Http.ModelBinding;
    using WebApiGoalProject.Models;

    public class LocationModelBinder
    {
        /// <summary>
        ///     Bind API request Model Async.
        /// </summary>
        /// <param name="bindingContext">The request object for operation.</param>
        /// <returns>A Completed Task.</returns>
        public bool BindModel(HttpActionContext actionContext, ModelBindingContext bindingContext)
        {
            if (bindingContext == null)
            {
                throw new ArgumentNullException(nameof(bindingContext));
            }

            if (bindingContext.ModelType != new LocationModel().GetType())
            {
                return false;
            }

            try
            {
                var request = actionContext.Request;
                using (var reader = request.Content.ReadAsStringAsync())
                {
                    string body = reader.GetAwaiter().GetResult();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"{"Error occurred while desearialization of request body."}", ex);
            }

            return true;
        }
    }
}