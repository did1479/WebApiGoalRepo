﻿namespace WebApiGoalProject.Models
{
    /// [Summary]
    ///     Model class for Location
    ///  [Summary]
    public class LocationModel
    {
        /// <summary>
        ///     Gets or sets the Locatin ID.
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///     Gets or sets the Location Name.
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        ///     Gets or sets the State
        /// </summary>
        public int State { get; set; }

        /// <summary>
        ///     Gets or sets the Country.
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        ///     Gets or sets the Longitude.
        /// </summary>
        public double Longitude { get; set; }

        /// <summary>
        ///     Gets or sets the Latitude.
        /// </summary>
        public double Latitude { get; set; }
    }
}
