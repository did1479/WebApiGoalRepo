﻿namespace WebApiGoalProject.interfaces
{
    using System.Collections.Generic;
    using System.Data.Services.Client;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using WebApiGoalProject.Models;

    public interface ISqlProvider
    {
        /// <summary>
        ///     Get all Locations.
        /// </summary>
        /// <returns>Location Details.</returns>
        Task<List<LocationModel>> GetSqlLocationsAsync();

        /// <summary>
        ///     Get Location Details.
        /// </summary>
        /// <param name="location">The name of location.</param>
        /// <returns>Location Details of given location.</returns>
        Task<LocationModel> GetSqlLocationDetailAsync(int locationId);

        /// <summary>
        ///     Add Location Details.
        /// </summary>
        /// <param name="model">Location model.</param>
        /// <returns>Add Location details result.</returns>
        Task<JsonResult> AddLocationToSqlAsync(LocationModel model);

        /// <summary>
        ///     Update Location Details.
        /// </summary>
        /// <param name="model">Location model.</param>
        /// <returns>Updated Location details result.</returns>
        Task<JsonResult> UpdateLocationToSqlAsync(LocationModel model);
        
        /// <summary>
        ///     Delete Location.
        /// </summary>
        /// <param name="model">Location model.</param>
        /// <returns>Deleted Location details result.</returns>
        Task<JsonResult> DeleteSqlLocationAsync(int locationId);
    }
}
