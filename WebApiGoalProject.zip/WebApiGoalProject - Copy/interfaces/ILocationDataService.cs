﻿namespace WebApiGoalProject.Location.interfaces
{
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using WebApiGoalProject.Models;

    /// <summary>
    ///     Location Data Service Interface.
    /// </summary>
    public interface ILocationDataService
    {
        /// <summary>
        ///     Get all Locations.
        /// </summary>
        /// <returns>Location Details.</returns>
        Task<JsonResult> GetLocations();

        /// <summary>
        ///     Get Location Details.
        /// </summary>
        /// <param name="location">The name of location.</param>
        /// <returns>Location Details of given location.</returns>
        Task<JsonResult> GetLocationDetail(int locationId);

        /// <summary>
        ///     Add Location Details.
        /// </summary>
        /// <param name="model">Location model.</param>
        /// <returns>Add Location details result.</returns>
        Task<JsonResult> AddLocation(LocationModel model);
        
        /// <summary>
        ///     Update Location Details.
        /// </summary>
        /// <param name="model">Location model.</param>
        /// <returns>Updated Location details result.</returns>
        Task<JsonResult> UpdateLocation(LocationModel model);

        /// <summary>
        ///     Update Location Details.
        /// </summary>
        /// <param name="locationId">Location Id.</param>
        /// <returns>Updated Location details result.</returns>
        Task<JsonResult> DeletedLocation(int locationId);
    }
}
