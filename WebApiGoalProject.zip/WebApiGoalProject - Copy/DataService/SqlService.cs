﻿namespace WebApiGoalProject.DataService
{
    using System;
    using System.Collections.Generic;
    using System.Data.SqlClient;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using WebApiGoalProject.interfaces;
    using WebApiGoalProject.Models;

    public class SqlService : ISqlProvider
    {
        /// <summary>
        ///     Initializes a new instance of the <see cref="SqlProvider" /> class.
        /// </summary>
        public SqlService()
        {
            this.SqlDataConnection = new SqlConnection { ConnectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=C:\\Users\\dsharma\\Documents\\WebAPIGoalProjectDB.mdf;Integrated Security=True;Connect Timeout=30"};
        }

        /// <summary>
        ///     Gets the SQL Data Service.
        /// </summary>
        private SqlConnection SqlDataConnection { get; }

        /// <summary>
        ///     Get all the Locations.
        /// </summary>
        /// <returns>The Response object for this operation.</returns>
        public async Task<List<LocationModel>> GetSqlLocationsAsync()
        {
            var response = new List<LocationModel>();

            using (var conn = this.SqlDataConnection)
            using (SqlCommand command = new SqlCommand("[dbo].[usp_GetAllLocations]", conn))
            {
                try
                {
                    conn.Open();
                    using (SqlDataReader reader = await command.ExecuteReaderAsync().ConfigureAwait(false))
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            var loc = new LocationModel
                            {
                                ID = reader.GetInt32(reader.GetOrdinal("ID")),
                                LocationName = reader.GetString(reader.GetOrdinal("LocationName")),
                                State = reader.GetInt32(reader.GetOrdinal("State")),
                                Country = reader.GetString(reader.GetOrdinal("CountryCode")),
                                Longitude = reader.GetDouble(reader.GetOrdinal("Longitude")),
                                Latitude = reader.GetDouble(reader.GetOrdinal("Latitude")),
                            };

                            response.Add(loc);
                        }
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    response = null;
                }
            }

            return response;
        }
        
        /// <summary>
        ///     Get all the Locations.
        /// </summary>
        /// <returns>The Response object for this operation.</returns>
        public async Task<LocationModel> GetSqlLocationDetailAsync(int locationId)
        {
            LocationModel response = null;

            using (var conn = this.SqlDataConnection)
            using (SqlCommand command = new SqlCommand("[dbo].[usp_GetLocationDetails]", conn))
            {
                var p = command.Parameters;
                p.Add(new SqlParameter("@LocationId", locationId));

                try
                {
                    conn.Open();
                    using (SqlDataReader reader = await command.ExecuteReaderAsync().ConfigureAwait(false))
                    {
                        while (await reader.ReadAsync().ConfigureAwait(false))
                        {
                            response = new LocationModel
                            {
                                ID = reader.GetInt32(reader.GetOrdinal("ID")),
                                LocationName = reader.GetString(reader.GetOrdinal("LocationName")),
                                State = reader.GetInt32(reader.GetOrdinal("State")),
                                Country = reader.GetString(reader.GetOrdinal("CountryCode")),
                                Longitude = reader.GetDouble(reader.GetOrdinal("Longitude")),
                                Latitude = reader.GetDouble(reader.GetOrdinal("Latitidue")),
                            };
                        }
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    response = null;
                }
            }

            return response;
        }
        
        /// <summary>
        ///     Add Location.
        /// </summary>
        /// <returns>The Response object for this operation.</returns>
        public async Task<JsonResult> AddLocationToSqlAsync(LocationModel loc)
        {
            var response = new JsonResult();
            using (var conn = this.SqlDataConnection)
            using (SqlCommand command = new SqlCommand("[dbo].[usp_AddLocationDetails]", conn))
            {
                var p = command.Parameters;
                p.Add(new SqlParameter("@LocationId", loc.ID));
                p.Add(new SqlParameter("@LocationName", loc.LocationName));
                p.Add(new SqlParameter("@State", loc.State));
                p.Add(new SqlParameter("@CountryCode", loc.Country));
                p.Add(new SqlParameter("@Longitude", loc.Longitude));
                p.Add(new SqlParameter("@Latitude", loc.Latitude));

                try
                {
                    conn.Open();
                    var res = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                    if (res > 0)
                    {
                        response.Data = "Location added successfully.";
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    response = null;
                }
            }

            return response;
        }

        /// <summary>
        ///     Update Location.
        /// </summary>
        /// <returns>The Response object for this operation.</returns>
        public async Task<JsonResult> UpdateLocationToSqlAsync(LocationModel updateModel)
        {
            var response = new JsonResult();
            using (var conn = this.SqlDataConnection)
            using (SqlCommand command = new SqlCommand("[dbo].[usp_UpdateLocationDetails]", conn))
            {
                var p = command.Parameters;
                p.Add(new SqlParameter("@LocationId", updateModel.ID));
                p.Add(new SqlParameter("@LocationName", updateModel.LocationName));
                p.Add(new SqlParameter("@State", updateModel.State));
                p.Add(new SqlParameter("@CountryCode", updateModel.Country));
                p.Add(new SqlParameter("@Longitude", updateModel.Longitude));
                p.Add(new SqlParameter("@Latitude", updateModel.Latitude));

                try
                {
                    conn.Open();
                    var res = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                    if (res > 0)
                    {
                        response.Data = "Location updated successfully.";
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    response = null;
                }
            }

            return response;
        }

        /// <summary>
        ///     Delete Location.
        /// </summary>
        /// <returns>The Response object for this operation.</returns>
        public async Task<JsonResult> DeleteSqlLocationAsync(int locationId)
        {
            var response = new JsonResult();
            using (var conn = this.SqlDataConnection)
            using (SqlCommand command = new SqlCommand("[dbo].[usp_DeleteLocationDetails]", conn))
            {
                var p = command.Parameters;
                p.Add(new SqlParameter("@LocationId", locationId));

                try
                {
                    conn.Open();
                    var res = await command.ExecuteNonQueryAsync().ConfigureAwait(false);
                    if (res > 0)
                    {
                        response.Data = "Location deleted successfully.";
                    }

                    conn.Close();
                }
                catch (Exception ex)
                {
                    string message = ex.Message;
                    response = null;
                }
            }

            return response;
        }
    }
}
