﻿namespace WebApiGoalProject.DataService
{
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using System.Web.Mvc;
    using WebApiGoalProject.interfaces;
    using WebApiGoalProject.Location.interfaces;
    using WebApiGoalProject.Models;

    /// <summary>
    ///     Weather Data Service.
    /// </summary>
    public class LocationDataService : ILocationDataService
    {
        /// <summary>
        ///     Gets the instance of the SQL Provider.
        /// </summary>
        protected ISqlProvider SqlProvider { get; }

        /// <summary>
        ///     Construct Location Data service.
        /// </summary>
        public LocationDataService()
        {
            SqlProvider = new SqlService();
        }

        /// <summary>
        ///     Get all Locations.
        /// </summary>
        /// <returns>Location Details.</returns>
        public async Task<JsonResult> GetLocations()
        {
            var locationResponse = await this.SqlProvider.GetSqlLocationsAsync().ConfigureAwait(false);
            if (locationResponse == null)
            {
                return new JsonResult { Data = new List<LocationModel>() };
            }

            return new JsonResult { Data = locationResponse };
        }

        /// <summary>
        ///     Get Location Details.
        /// </summary>
        /// <param name="locationId">The Id of location.</param>
        /// <returns>Location Details of given location.</returns>
        public async Task<JsonResult> GetLocationDetail(int locationId)
        {
            var locationResponse = await this.SqlProvider.GetSqlLocationDetailAsync(locationId).ConfigureAwait(false);
            if (locationResponse == null)
            {
                return new JsonResult { Data = new LocationModel() };
            }

            return new JsonResult { Data = locationResponse };
        }

        /// <summary>
        ///     Add Location.
        /// </summary>
        /// <param name="model">Location model to Add.</param>
        /// <returns>Operation Result.</returns>
        public async Task<JsonResult> AddLocation(LocationModel model)
        {
            var locationAddResponse = await this.SqlProvider.AddLocationToSqlAsync(model).ConfigureAwait(false);
            if (locationAddResponse == null)
            {
                return new JsonResult { Data = "Location add failed." };
            }

            return new JsonResult { Data = locationAddResponse };
        }

        /// <summary>
        ///     Upldate Location model.
        /// </summary>
        /// <param name="model"></param>
        /// <returns>Operation Result.</returns>
        public async Task<JsonResult> UpdateLocation(LocationModel model)
        {
            var locationUpdateResponse = await this.SqlProvider.UpdateLocationToSqlAsync(model).ConfigureAwait(false);
            if (locationUpdateResponse == null)
            {
                return new JsonResult { Data = "Location update failed." };
            }

            return new JsonResult { Data = locationUpdateResponse };
        }

        /// <summary>
        ///     Delete Location.
        /// </summary>
        /// <param name="locationId">Location Id to delete.</param>
        /// <returns>Operation Result.</returns>
        public async Task<JsonResult> DeletedLocation(int locationId)
        {
            var locationDeleteResponse = await this.SqlProvider.DeleteSqlLocationAsync(locationId).ConfigureAwait(false);
            if (locationDeleteResponse == null)
            {
                return new JsonResult { Data = "Location delete failed." };
            }

            return new JsonResult { Data = locationDeleteResponse };
        }
    }
}
