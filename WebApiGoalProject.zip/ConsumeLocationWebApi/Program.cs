﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace ConsumeLocationWebApi
{
    class Program
    {
        static void Main(string[] args)
        {
            int operationCode;
            Int32.TryParse(Console.ReadLine(), out operationCode);
            switch (operationCode)
            {
                case 1:
                    CallWebAPIHelloWorldMethodAsync().Wait();
                    break;
                case 2:
                    GetLocationsFromApiAsync().Wait();
                    break;
                case 3:
                    GetLocationDetailsFromApiAsync().Wait();
                    break;
                case 4:
                    AddLocationUsingApiAsync().Wait();
                    break;
                case 5:
                    UpdateLocationUsingApiAsync().Wait();
                    break;
                case 6:
                    DeleteLocationUsingApiAsync().Wait();
                    break;
                default:
                    break;
            }
        }

        /// <summary>
        ///     Test API Hello World method.
        /// </summary>
        /// <returns></returns>
        static async Task CallWebAPIHelloWorldMethodAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost/WebApi/locationapi/HelloWorld");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage response = await client.GetAsync(client.BaseAddress);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(result);
                    Console.Read();
                }
                else
                {
                    Console.WriteLine("Internal server Error");
                }
            }
        }
        
        /// <summary>
        ///     Test API GetLocations method.
        /// </summary>
        /// <returns></returns>
        static async Task GetLocationsFromApiAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost/WebApi/locationapi/GetLocations");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage response = await client.GetAsync(client.BaseAddress);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(result);
                    Console.Read();
                }
                else
                {
                    Console.WriteLine("Internal server Error");
                }
            }
        }

        /// <summary>
        ///     Test API GetLocationDetails method.
        /// </summary>
        /// <returns></returns>
        static async Task GetLocationDetailsFromApiAsync()
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri("https://localhost/WebApi/locationapi/GetLocationDetails/1");
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                //GET Method  
                HttpResponseMessage response = await client.GetAsync(client.BaseAddress);
                if (response.IsSuccessStatusCode)
                {
                    var result = await response.Content.ReadAsStringAsync();
                    Console.WriteLine(result);
                    Console.Read();
                }
                else
                {
                    Console.WriteLine("Internal server Error");
                }
            }
        }
        
        /// <summary>
        ///     Test API AddLocationDetails method.
        /// </summary>
        /// <returns></returns>
        static async Task AddLocationUsingApiAsync()
        {
            var locModel = new LocationModel
            {
                ID = 4,
                LocationName = "Test Location",
                State = 11,
                Country = "IN",
                Longitude = 25.365989,
                Latitude = 45.236598
            };

            string json = JsonConvert.SerializeObject(locModel, Newtonsoft.Json.Formatting.Indented);
            var buffer = Encoding.UTF8.GetBytes(json);

            HttpResponseMessage response;
            using (var byteContent = new ByteArrayContent(buffer))
            {
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost/WebApi/locationapi/AddLocation");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    response = await client.PostAsync(client.BaseAddress, byteContent).ConfigureAwait(false);
                    if (response.IsSuccessStatusCode)
                    {
                       var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        Console.WriteLine(result);
                        Console.Read();
                    }
                    else
                    {
                        Console.WriteLine("Internal server Error");
                    }
                }
            }
        }

        /// <summary>
        ///     Test API UpdateLocationDetails method.
        /// </summary>
        /// <returns></returns>
        static async Task UpdateLocationUsingApiAsync()
        {
            var updateModel = new LocationModel
            {
                ID = 1,
                LocationName = "Test Location update",
                State = 51,
                Country = "US",
                Longitude = 58.569823,
                Latitude = 54.789654
            };

            string json = JsonConvert.SerializeObject(updateModel, Newtonsoft.Json.Formatting.Indented);
            var buffer = Encoding.UTF8.GetBytes(json);

            HttpResponseMessage response;
            using (var byteContent = new ByteArrayContent(buffer))
            {
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost/WebApi/locationapi/UpdateLocation");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    response = await client.PostAsync(client.BaseAddress, byteContent).ConfigureAwait(false);
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        Console.WriteLine(result);
                        Console.Read();
                    }
                    else
                    {
                        Console.WriteLine("Internal server Error");
                    }
                }
            }
        }

        /// <summary>
        ///     Test API Delete method.
        /// </summary>
        /// <returns></returns>
        static async Task DeleteLocationUsingApiAsync()
        {
            var buffer = Encoding.UTF8.GetBytes("2");

            HttpResponseMessage response;
            using (var byteContent = new ByteArrayContent(buffer))
            {
                byteContent.Headers.ContentType = new MediaTypeHeaderValue("application/json");

                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("https://localhost/WebApi/locationapi/DeleteLocation");
                    client.DefaultRequestHeaders.Accept.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    response = await client.PostAsync(client.BaseAddress, byteContent).ConfigureAwait(false);
                    if (response.IsSuccessStatusCode)
                    {
                        var result = await response.Content.ReadAsStringAsync().ConfigureAwait(false);
                        Console.WriteLine(result);
                        Console.Read();
                    }
                    else
                    {
                        Console.WriteLine("Internal server Error");
                    }
                }
            }
        }
    }

    /// [Summary]
    ///     Model class for Location
    ///  [Summary]
    public class LocationModel
    {
        /// <summary>
        ///     Gets or sets the Locatin ID.
        /// </summary>
        public int ID { get; set; }

        /// <summary>
        ///     Gets or sets the Location Name.
        /// </summary>
        public string LocationName { get; set; }

        /// <summary>
        ///     Gets or sets the State
        /// </summary>
        public int State { get; set; }

        /// <summary>
        ///     Gets or sets the Country.
        /// </summary>
        public string Country { get; set; }

        /// <summary>
        ///     Gets or sets the Longitude.
        /// </summary>
        public double Longitude { get; set; }

        /// <summary>
        ///     Gets or sets the Latitude.
        /// </summary>
        public double Latitude { get; set; }
    }
}
